#include<string.h>
#include <iostream>
using namespace std;
class Jewel
{
  private:
	int id;
	char design[20];
	int cost_per_gram;
	float gst;
  public:
    Jewel();
    void get_data();
	void display_data();
	Jewel operator=(Jewel);
	bool operator==(Jewel);
	int get_id();
};
class MinHeap
{
	private:
	 int h_size;
	 Jewel *array;
	 int capacity;
	public:
	 MinHeap(int);
	 bool is_empty();
	 bool is_full();
	 bool en_queue(Jewel);
	 Jewel de_queue();
	 Jewel find_min();
	 Jewel search(int);
	 bool display();
};