#include "heap.h"
int main()
{
	int cap;
	cout<<"\nEnter capacity of your store: ";
	cin>>cap;
	MinHeap m(cap);
	int choice;
	do
	{
		cout<<"\nMenu: ";
		cout<<"\n1.check whether ths store is empty";
		cout<<"\n2.check whether the store is full";
		cout<<"\n3.add a new jewel";
		cout<<"\n4.remove a jewel";
		cout<<"\n5.search for a jewel by jewel_id";
		cout<<"\n6.display all the jewels";
		cout<<"\n7.exit\n";
		cout<<"\nenter your choice: ";
		cin>>choice;
		if(choice==1)
		{
			if(m.is_empty())
			  cout<<"\nYes the store is empty";
		    else 
			  cout<<"\nNo the store is not empty";
		}
		if(choice==2)
		{
			if(m.is_full())
			  cout<<"\nYes the store is full";
			else
			  cout<<"\nThe store is not full";
		}
		if(choice==3)
		{
			Jewel j;
			j.get_data();
			bool cases=m.en_queue(j);
			if(cases==true)
			  cout<<"\nsuccessfully added";
			else
			  cout<<"\nstore is full ,no space for further jewel to get added";
		}
		if(choice==4)
		{
			Jewel test=m.de_queue();
			Jewel empty;
			if(test==empty)
			  cout<<"\no jewel to get removed";
			else
			{
			  cout<<"\ndeleted jewel: ";
			  test.display_data();
			}
		}
		if(choice==5)
		{
		    cout<<"\nEnter the jewel_id to search: ";
			int id;
			cin>>id;
			Jewel test=m.search(id);
			Jewel empty;
			if(test==empty)
			  cout<<"\nno jewel with this id";
			else
			{
			   cout<<"\njewel you are serching for this";
			   test.display_data();
			}  
		}
		if(choice==6)
		{
			if(!m.is_empty())
			  m.display();
			else
			  cout<<"\nnothing to display";
		}
		if(choice==7)
		  break;
	}while(choice!=7);
}