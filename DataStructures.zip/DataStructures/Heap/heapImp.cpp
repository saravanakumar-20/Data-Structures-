#include "heap.h"
Jewel::Jewel()
{
	id=0;
	strcpy(design,"null");
	cost_per_gram=0;
	gst=0.0;
}
Jewel Jewel::operator=(Jewel j)
{
	id=j.id;
	strcpy(design,j.design);
	cost_per_gram=j.cost_per_gram;
	gst=j.gst;
	return *this;
}
int Jewel::get_id()
{
	return id;
}
bool Jewel::operator==(Jewel j)
{
	return j.id==id;
}
void Jewel::get_data()
{
	cout<<"\nEnter Jewel_id:";
	cin>>id;
	cout<<"\nEnter Jewel_design: ";
	cin>>design;
	cout<<"\nEnter Jewel_gst: ";
	cin>>gst;
	cout<<"\nEnter cost_per_gram: ";
	cin>>cost_per_gram;
}
void Jewel::display_data()
{
	cout<<"\nJewel_id: "<<id;
	cout<<"\nJewel_design: "<<design;
	cout<<"\nJewel_gst: "<<gst;
	cout<<"\ncost_per_gram: "<<cost_per_gram;
	cout<<"\n";
}
MinHeap::MinHeap(int cap)
{
	h_size=0;
	capacity=cap;
	array=new Jewel[capacity+1];
}
bool MinHeap::is_full()
{
	return capacity==h_size;
}
bool MinHeap::is_empty()
{
	return h_size==0;
}
bool MinHeap::en_queue(Jewel j)
{
	if(is_full())
	  return false;
	else
	{
	  int count_node=++h_size;
	  while(count_node!=1 && array[count_node/2].get_id()>j.get_id())
	  {
		  array[count_node]=array[count_node/2];
		  count_node=count_node/2;
	  }
	  array[count_node]=j;
	  return true;
	}
}
Jewel MinHeap::de_queue()
{
	if(is_empty())
	{
		Jewel test;
		return test;
	}
	else
	{
		Jewel return_jewel=array[1];
		Jewel last_jewel=array[h_size--];
		int low_child=2;
		int count_node=1;
		while(low_child<=h_size)
		{
			if(low_child<h_size && array[low_child].get_id()>array[low_child+1].get_id())
			  low_child++;
			if(last_jewel.get_id()<=array[low_child].get_id())
			  break;
			array[count_node]=array[low_child];
			count_node=low_child;
			low_child=count_node*2;
		}
		array[count_node]=last_jewel;
		return return_jewel;
	}
}
Jewel MinHeap::find_min()
{
		if(!is_empty())
		   return array[1];
		Jewel test;
		return test;
}
	Jewel MinHeap::search(int idi)
	{
		if(!is_empty())
		{
			int i;
			for(i=1;i<=h_size;i++)
			   if(array[i].get_id()==idi)
			      return array[i];
		}
		Jewel test;
		return test;
	}
	bool MinHeap::display()
	{
		if(!is_empty())
		{
			int i;
			for(i=1;i<=h_size;i++)
			    array[i].display_data();
		    return true;
		 }
		 return false;
	}
