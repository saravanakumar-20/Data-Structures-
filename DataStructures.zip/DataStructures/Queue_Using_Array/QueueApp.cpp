#include"Queue.h"
int main()
{
	cout<<"\n********QueueADT Implementation Using Array*********\n";
	int capacity;
	cout<<"\nEnter The Capacity Of Store: ";
	cin>>capacity;
	int choice;
        Queue q1(capacity);
        do
        {
		cout<<"\n      -----      ";
		cout<<"\n      menu:      ";
		cout<<"\n      -----      \n";
		cout<<"\n...................";
		cout<<"\n.                 .";
                cout<<"\n.1.Check Whether The Store Is Full         ";
                cout<<"\n.2.Check Whether The Store Is Empty     ";
                cout<<"\n.3.Add A Jewel        ";
                cout<<"\n.4.Buy A Jewel        ";
                cout<<"\n.5.Buy All The Jewels ";
		cout<<"\n.6.Get The Recently Added Jewel    ";
		cout<<"\n.7.Get The Total Number Of Jewels Available        ";
		cout<<"\n.8.Display All The Jewels Available   ";
                cout<<"\n.9.Exit           .";
		cout<<"\n...................";
		cout<<"\n\nEnter Your Choice: ";
		cin>>choice;
                if(choice==1)
                {
                   if(q1.isFull())
                           cout<<"\nYes Store Is Full!\n";
                   else
                           cout<<"\nNo Store Is Not Full!\n";
                }
                else if(choice==2)
                {
                  if(q1.isEmpty())
                          cout<<"\nYes Store Is Empty!\n";
                  else
                          cout<<"\nNo Store Is Not Empty!\n";
                }
                else if(choice==3)
                {
			Jewel j;           
			cout<<"\nEnter Details:\n\n";
			cin>>j;
                        if(q1.enQueue(j))
                                cout<<"\nSuccessFully Added!\n";
			else
				cout<<"\nTotal Capacity Of Store Is Occupied Unable To Add A Jewel!\n";
                }
		else if(choice==4)
		{
			if(!q1.isEmpty())
			{
				cout<<"\nSuccessfully Bought!\n";
				cout<<"\nBought Jewel: \n";
				Jewel j=q1.deQueue();
				cout<<j;
			}
			else
				cout<<"\nStore Is Empty Nothing There To Buy!\n";
		}
		else if(choice==5)
		{
			if(q1.makeQueueEmpty())
				cout<<"\nAll The Jewels Were Bought Successfully!\n";
			else
				cout<<"\nStore Is Already Empty!\n";
		}
		else if(choice==7)
		{
			int size=q1.getSize();
			cout<<"\nTotal Number Of Jewels Available: "<<size;
		}
		else if(choice==6)
		{
			if(!q1.isEmpty())
			{
				Jewel j = q1.getPeak();
				cout<<"\n     Recently Added Jewel:     \n";
				cout<<j;
			}
			else
				cout<<"\nStore Already Empty! Nothing There To Get!\n";
		}
		else if(choice==8)
		{
			if(!q1.displayQueue())
				cout<<"\nNothing There To Display..Store Being Empty!\n";
		}
		else if(choice==9)
			break;
		else
			cout<<"\nInvalid Option Chosen! Press Valid Key\n";
	}while(choice!=9);

}
