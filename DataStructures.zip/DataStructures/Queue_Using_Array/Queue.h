#include<iostream>
#include<string.h>
using namespace std;
class Jewel
{
	public:
	      Jewel();
	      bool operator==(Jewel);
	      Jewel operator=(Jewel);
	      Jewel operator=(int);
	      friend istream& operator>>(istream&,Jewel&);
	      friend ostream& operator<<(ostream&,Jewel&);
       private:
	      int id;
	      int costPerGram;
	      float gst;
	      char design[20];

};
class Queue
{
   private: 
	  Jewel *jewelArray;
	  int capacity;
	  int rear;
	  int front;
    public:
	  Queue();
	  Queue(int);
	  Jewel deQueue();
	  int enQueue(Jewel);
	  int isFull();
	  int isEmpty();
	  int makeQueueEmpty();
	  Jewel getPeak();
	  int getSize();
	  int displayQueue();
};
