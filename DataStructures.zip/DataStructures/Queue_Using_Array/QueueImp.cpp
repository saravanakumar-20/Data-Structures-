#include"Queue.h"
Jewel::Jewel()
{
	id=0;
        strcpy(design,"null");
	costPerGram=0;
	gst=0.0;
}
/*Jewel::Jewel(const Jewel &j)
{
	id=j.id;
	strcpy(design,j.design);
	costPerGram=j.costPerGram;
	gst=j.gst;
}*/
Jewel Jewel::operator=(int x)
{
	id=x;
	strcpy(design,"-1");
	costPerGram=x;
	gst=float(x);
	return *this;
}
Jewel Jewel::operator=(Jewel j)
{
	strcpy(design,j.design);
	id=j.id;
	gst=j.gst;
	costPerGram=j.costPerGram;
	return *this;
}
istream& operator>>(istream &myin,Jewel &j)
{
	cout<<"Enter Id: ";
	myin>>j.id;
	cout<<"\nEnter Design: ";
	myin>>j.design;
	cout<<"\nEnter Gst: ";
	myin>>j.gst;
	cout<<"\nEnter Cost Of One Gram: ";
	myin>>j.costPerGram;
	return myin;
}
ostream& operator<<(ostream &myout,Jewel &j)
{
	myout<<"\nId: "<<j.id;
	myout<<"\tDesign: "<<j.design;
	myout<<"\tGst: "<<j.gst;
	myout<<"\tCostPerGram: "<<j.costPerGram<<"\n";
	return myout;
}
Queue::Queue(int cap)
{
	capacity=cap;
	front=0;
	rear=0;
	jewelArray = new Jewel[capacity];
}
int Queue::isFull()
{ 
	return rear==capacity;
}
int Queue::isEmpty()
{
	return rear==front;
}
Jewel Queue::deQueue()
{
	Jewel j=jewelArray[front];
	front++;
	return j;
}
int Queue::enQueue(Jewel j)
{
	if(!isFull())
	{
	    jewelArray[rear]=j;
	    rear++;
	    return 1;
	}
	return 0;
}
int Queue::makeQueueEmpty()
{
	if(!isEmpty())
	{
		while(!isEmpty())
		{
			deQueue();
		}
		return 1;
	}
	return 0;
}
int Queue::getSize()
{
	if(!isEmpty())
	   return rear-(front);
	return 0;
}
Jewel Queue::getPeak()
{
	int r=rear-1;
	return jewelArray[r];
}
int Queue::displayQueue()
{
	if(!isEmpty())
	{
		for(int i=front;i<rear;i++)
			cout<<jewelArray[i];
		return 1;
	}
	return 0;
}
