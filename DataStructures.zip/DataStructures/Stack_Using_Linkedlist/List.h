#include<string.h>
#include<iostream>
using namespace std;
class Jewel
{
   private:
	  int id;
	  char design[20];
	  float gst;
	  int costPerGram;
   public:
	 Jewel();
         Jewel(const Jewel&);
	 friend istream& operator>>(istream&,Jewel&);
	 friend ostream& operator<<(ostream&,Jewel&);
	 Jewel operator=(Jewel);
	 bool operator==(Jewel); 
};
class Node
{
  private:
	 Jewel data;
	 Node *next; 
   public:
	 Node();
	 Node(Jewel,Node*);
	 Node(const Node&);
	 ~Node();
	 friend class Queue;
	 friend class Stack;
};
class Queue
{
  private:
	 Node *first;
  public:
	 Queue();
	 Queue(Node*);
	 Queue(const Queue&);
	 ~Queue();
	 Jewel getPeak();
	 int displayQueue();
	 int makeQueueEmpty();
	 int getSize();
	 int enQueue(Node*);
	 Jewel deQueue();
	 int isEmpty();

	 
};
class Stack
{
  private:
	  Node *first;
   public:
	  Stack();
	  Stack(Node*);
	  Stack(const Stack&);
	  ~Stack();
	  Jewel getPeak();
	  int displayStack();
	  int makeStackEmpty();
	  int getSize();
	  int push(Node *);
	  Jewel pop();
	  int isEmpty();
};
