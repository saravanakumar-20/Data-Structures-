#include"List.h"
int main()
{
	int ch;
     cout<<"\n--------Queue And Stack Implementation Using Linked List--------\n";
	do
	{
	 cout<<"\n        menu:\n";
	 cout<<"\n1.Queue Implementation\n";
     cout<<"\n2.Stack Implementation\n";
	 cout<<"\n3.Exit\n";
     cout<<"\nEnter Your Choice: ";
	 int choice;
     cin>>ch;
     if(ch==1)
       { 
	Queue q;
	do
	{  
		cout<<"\n        menu\n";
		cout<<"\n1.Check Whether The Store Is Empty\n";
		cout<<"\n2.Add A New Jewel\n";
		cout<<"\n3.Buy A Old Jewel\n";
		cout<<"\n4.Buy All The Jewel\n";
		cout<<"\n5.Get The Recently Added Jewel\n";
		cout<<"\n6.Display All The Jewel Available In Store\n";
		cout<<"\n7.Get The Total Number Of Jewel Available\n";
		cout<<"\n8.Exit\n";
		cout<<"\nEnter Your Choice: ";
		cin>>choice;
		if(choice==1)
		{
			if(q.isEmpty())
				cout<<"\nYes Store Is Empty!\n";
			else
				cout<<"\nNo Store Is Not Empty!\n";
		}
		else if(choice==4)
		{
			if(q.makeQueueEmpty())
				cout<<"\nAll The Jewels Were Bought Store Is Empty Now!\n";
			else
			        cout<<"\nStore Is Already Empty\n";
		}
		else if(choice==5)
		{
			if(!q.isEmpty())
			{
				Jewel j=q.getPeak();
				cout<<"\n      Recently Added Jewel    \n";
			        cout<<j;	
			}
			else
				cout<<"\nNothing Is There To Display\n";
		}
		else if(choice==6)
		{
			if(!q.displayQueue())
				cout<<"\nNothing Is There To Display!\n";
		}
		else if(choice==7)
		{
			int size=q.getSize();
			cout<<"\nTotal Number Of Jewels Available: "<<size<<"\n";
		}
		else if(choice==2)
		{
			Jewel j;
			cout<<"\n    Enter The Data:     \n";
		        cin>>j;
		        Node *newnode = new Node(j,NULL);
		        if(q.enQueue(newnode))
			   cout<<"\nData Was Added Successfully!\n";	
		}
		else if(choice==3)
		{
			if(q.isEmpty())
				cout<<"\nNothing There To Buy!\n";
			else
			{
				Jewel j=q.deQueue();
				cout<<"\n    Bought Data:   \n";
				cout<<j;
				cout<<"\n";
			}
		}
		else if(choice==8)
	               break;
		else
			cout<<"\nIvalid Key Has Been Pressed! Press The Valid Key.\n";
         
	}while(choice!=8);
       }
     else if(ch==2)
     {
	     Stack s;
	     do
	     {
		     cout<<"\n    menu\n";
		     cout<<"\n1.Check Whether The Store Is Empty\n";
		     cout<<"\n2.Add A Jewel\n";
		     cout<<"\n3.Buy A Jewel\n";
		     cout<<"\n4.Get The Recently Added Jewel\n";
		     cout<<"\n5.Display All The Jewels Available In The Store\n";
		     cout<<"\n6.Buy All The Jewels\n";
		     cout<<"\n7.Get The Total Number Of Jewels Available\n";
		     cout<<"\n8.exit\n";
		     cout<<"\nEnter Your Choice: ";
		     cin>>choice;
		     if(choice==1)
		     {
			     if(s.isEmpty())
				     cout<<"\nYes Store  Is Empty!\n";
			     else
				     cout<<"\nNot Empty!\n";

		     }
		     else if(choice==2)
		     {
			     Jewel j;
			     cout<<"\nEnter The Data: \n";
			     cin>>j;
			     Node *newnode = new Node(j,NULL);
			     s.push(newnode);
			     cout<<"\nSuccessFully Pushed!\n";
		     }
		     else if(choice==3)
		     { 
			     if(!s.isEmpty())
			     {
				     Jewel j=s.pop();
				     cout<<"\n     Bought Jewel\n";
				     cout<<j;
			     }
			     else
				     cout<<"\nStore Is Being Empty!\n";

		     }
		     else if(choice==4)
		     { 
			     if(!s.isEmpty())
			     {
				     Jewel j=s.getPeak();
				     cout<<"\n      Recently Added Jewel\n";
				     cout<<j;
				     cout<<"\n";
			     }
			     else
				cout<<"\nStore Is Being Empty ! There Is No Recently Added Jewel.\n";

		     }
		     else if(choice==5)
		     {
			     if(!s.displayStack())
				     cout<<"\nNothing There To Display!\n";

		     }
		     else if(choice==6)
		     {
			     if(s.makeStackEmpty())
				     cout<<"\nAll The Jewels Were Bought Successfully! Store Is Empty Now\n";
			     else
				     cout<<"\nStore Already Empty!\n";
		     }
		     else if(choice==7)
		     {
			     int size=s.getSize();
			     cout<<"\nTotal Number Of Jewels Available: "<<size<<"\n";
		     }
		     else if(choice==8)
			     break;
		     else
			     cout<<"\nIvalid Key Has Been Pressed..Hit The Valid Key!\n";
	     }while(choice!=8);

     }
	 else if(ch==3)
	        break;
	 else
	    cout<<"\nInvalid Option Given! Press The Valid Key...\n";
	}while(ch!=3);
}
