#include"List.h"
Jewel::Jewel()
{
	id=0;
	strcpy(design,"saravana");
	costPerGram=0;
	gst=0.0;
}
Jewel::Jewel(const Jewel& j)
{ 
	id=j.id;
	strcpy(design,j.design);
	costPerGram=j.costPerGram;
	gst=j.gst;
}
istream& operator>>(istream& myin,Jewel &j)
{
	cout<<"\nEnter Id: ";
	myin>>j.id;
	cout<<"\nEnter Design: ";
	myin>>j.design;
	cout<<"\nEnter Gst: ";
	myin>>j.gst;
	cout<<"\nEnter CostPerGram: ";
	myin>>j.costPerGram;
	return myin;
}
ostream& operator<<(ostream& myout,Jewel &j)
{
	myout<<"\nJewel Id: "<<j.id;
	myout<<"\tJewel Design: "<<j.design;
	myout<<"\tJewel Gst: "<<j.gst;
	myout<<"\tJewel CostPerGram: "<<j.costPerGram;
	return myout;
}
Jewel Jewel::operator=(Jewel j)
{
	id=j.id;
	costPerGram=j.costPerGram;
	gst=j.gst;
	strcpy(design,j.design);
	return j;
}
bool Jewel::operator==(Jewel j)
{
	if((id==j.id)&&(gst==j.gst)&&(costPerGram==j.costPerGram)&&(strcmp(design,j.design)==0))
		return 1;
	return 0;
}
Node::Node()
{
	Jewel j;
	data=j;
	next=NULL;
}
Node::~Node()
{
	delete next;
}
Node::Node(const Node& n )
{
	data=n.data;
	next=n.next;
}
Node::Node(Jewel j,Node* n)
{
	data=j;
	next=n;
}
int Queue::isEmpty()
{
	return first==NULL;
    
}
Queue::Queue()
{
	first=NULL;
}
Queue::Queue(Node *n)
{
	first=n;
}
Queue::Queue(const Queue &q)
{
	first=q.first;
}
int Queue::enQueue(Node *n)
{
        if(!isEmpty())
	{
		Node *temp=first;
		while(temp->next!=NULL)
		{
			temp=temp->next;
		}
		temp->next=n;
		return 1;
	}
	first=n;
	return 1;
}

Jewel Queue::deQueue()
{
		Jewel j;
		Node *temp=first;
		j=temp->data;
		first=first->next;
		temp=NULL;
		return j;
}
Jewel Queue::getPeak()
{
	Node *temp=first;
	while(temp->next!=NULL)
		temp=temp->next;
	return temp->data;
}
int Queue::getSize()
{
	int cnt=0;
	Node *temp=first;
	while(temp!=NULL)
	{
		temp=temp->next;
		cnt++;
	}
	return cnt;
}
int Queue::displayQueue()
{
	if(!isEmpty())
	{ 
		Node *temp=first;
		cout<<"\n";
		while(temp!=NULL)
		{
			cout<<temp->data;
			cout<<"\n";
			temp=temp->next;
		}
		cout<<"\n";
		return 1;
	}
	return 0;

}
int Queue::makeQueueEmpty()
{  
       if(!isEmpty())
       {
	       while(!isEmpty())
		       deQueue();
	       return 1;
       }
       return 0;

}
Queue::~Queue()
{
	delete first;
}
int Stack::isEmpty()
{
	return first==NULL;
}
Stack::Stack()
{
	first=NULL;
}
Stack::Stack(const Stack &s)
{
	first=s.first;
}
Stack::Stack(Node *n)
{
	first=n;
}
Stack::~Stack()
{
	delete first;
}
int Stack::push(Node *newnode)
{
	if(!isEmpty())
	{
		Node *temp=first;
		while(temp->next!=NULL)
		{
			temp=temp->next;
		}
		temp->next=newnode;
		return 1;
	}
	first=newnode;
	return 1;
}
Jewel Stack::pop()
{
	Jewel j;
	Node *temp=first;
	Node *prev;
	if(temp->next==NULL)
	{
		j=temp->data;
		first=NULL;
	}
	else
	{
	    while(temp->next!=NULL)
	    {
		    prev=temp;
		    temp=temp->next;
	    }
	    prev->next=NULL;
	    j=temp->data;
	    delete temp;
	}
	return j;
}
Jewel Stack::getPeak()
{
	Node *temp=first;
	while(temp->next!=NULL)
		temp=temp->next;
	Jewel j=temp->data;
	return j;
}
int Stack::getSize()
{   
	int cnt=0;
	Node *temp=first;
	while(temp!=NULL)
	{
		cnt++;
		temp=temp->next;
	}
	return cnt;
}
int Stack::makeStackEmpty()
{
	if(!isEmpty())
	{
		Node *temp=first;
		while(!isEmpty())
		{
			delete temp;
			first=first->next;
			Node* temp=first; 
		}
		return 1;
	}
	return 0;
}
int Stack::displayStack()
{
	if(!isEmpty())
	{
		Jewel j[getSize()];
		Node *temp=first;
		int i=0;
		while(temp!=NULL)
		{
			j[i]=temp->data;
			temp=temp->next;
			i++;
		}
		for(int i=getSize()-1;i>=0;i--)
		   cout<<"\n"<<j[i]<<"\t";
		cout<<"\n";
		return 1;
	}
	return 0;
}
