#include"AVL.h"
int main()
{
  AVL_Tree avl;
  Jewel j;
  int c;
  int choice;
  do
  {
	  cout<<"\n\nMenu: \n";
	  cout<<"\n1.Add A Jewel\n";
	  cout<<"\n2.Display Jewels By Inorder Fashion\n";
	  cout<<"\n3.Display The Jewel By Postorder Fashion\n";
	  cout<<"\n4.Display The Jewel By Preorder Fashion\n";
	  cout<<"\n5.Search The Jewel By CostPerGram\n";
	  cout<<"\n6.To Make The Store Empty\n";
	  cout<<"\n7.Check Whether The Store Is Empty\n";
	  cout<<"\n8.Exit\n";
	  cout<<"\nEnter Your Choice: ";
	  cin>>choice;
	  if(choice==1)
	  {
		  cout<<"\nEnter The JewelDetails: \n";
		  cin>>j;
		  Node *newnode = new Node(0,j,NULL,NULL);
		  Node *temp=avl.insert(avl.getRoot(),newnode);
		  if(temp!=NULL)
		     cout<<"\nInsertion Successsful!\n";
	      else
		     cout<<"\nDuplicate Jewels Are Not Allowed Inside The Store!\n";
	  }
	  else if(choice==2)
	  {
		 if(!avl.isEmpty())
		 {
		  cout<<"\n             Displayed By Inorder Traversal\n";
		  avl.inorder(avl.getRoot());
		 }
		 else
		   cout<<"\nStore Is Empty Nothing To Display!\n";
	  }
	  else if(choice==3)
	  {
		 if(!avl.isEmpty())
		 {
		  cout<<"\n             Displayed By Postorder Traversal\n";
		  avl.postorder(avl.getRoot());
		 }
		 else
		  cout<<"\nStore Is Empty Nothing To Display!\n";
	  }
	  else if(choice==4)
	  {
		 if(!avl.isEmpty())
		 {
		  cout<<"\n             Displayed By Preorder Traversal\n";
		  avl.preorder(avl.getRoot());
		 }
		 else
		  cout<<"\nStore Is Empty Nothing To Display!\n";
	  }
	  else if(choice==5)
	  {
		  if(!avl.isEmpty())
		  {
			  cout<<"\nEnter The CostPerGram To Search: ";
			  cin>>c;
			  Jewel key(c);
			  Jewel test;
			  Jewel returned;
			  returned=avl.search(key);
			  if(returned==test)
			    cout<<"\nThere Is No Jewel Available With This CostPerGram!\n";
			  else
			  {
				  cout<<"\nThe Jewel You Are Looking For Is:\n";
				  cout<<returned;
			  }
		  }
		  else
		   cout<<"\nStore Is Empty Search Operation Is Meaningless Here!\n";
	  }
	  else if(choice==6)
	  {
		  if(!avl.isEmpty())
		  {
			  cout<<"\nStore Was Empty!\n";
			  avl.makeListEmpty();
		  }
		  else
		    cout<<"\nStore Is Already Empty!\n";
	  }
	  else if(choice==7)
	  {
		  if(avl.isEmpty())
		     cout<<"\nYes The Store Is Empty\n";
		  else
		     cout<<"\nStore Is Not Empty\n";
	  }
	  else if(choice==8)
	  {
		  break;
	  }
	  else
	  {
		  cout<<"\nInvalid Input! Give Valid Input...\n";
	  }
  }while(choice!=8);
}