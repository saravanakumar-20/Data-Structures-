#include<iostream>
#include<string.h>
using namespace std;
class Jewel
{
	public:
	  Jewel();
	  Jewel(int,char*,int,float);
	  Jewel(const Jewel&);
	  Jewel(int);
	  bool operator==(Jewel);
	  bool operator!=(Jewel);
	  Jewel operator=(Jewel);
	  Jewel operator=(int);
	  bool operator<(Jewel);
	  bool operator>(Jewel);
	  friend istream& operator>>(istream &,Jewel &);
	  friend ostream& operator<<(ostream &,Jewel &);
	private:
	   int jewelId;
	   int costPerGram;
	   char design[20];
	   float gst;
	   
};
class Node
{
	private:
	   Jewel data;
	   int height;
	   Node* left;
	   Node* right;
	public:
	   Node();
	   Node(int,Jewel,Node*,Node*);
	   Node(const Node&);
	   ~Node();
	   friend class AVL_Tree;
};
class AVL_Tree
{
	private:
	   Node *root;
	public:
	   AVL_Tree();
	   AVL_Tree(Node*);
	   AVL_Tree(const AVL_Tree&);
	   ~AVL_Tree();
	   int height(Node *);
	   int findBF(Node *);
	   Node* LLRotate(Node *);
	   Node* RRRotate(Node *);
	   Node* LRRotate(Node *);
	   Node* RLRotate(Node *);
	   int max(int,int);
	   Node* insert(Node*,Node*);
	   Node* getRoot();
	   int isEmpty();
	   Jewel search(Jewel);
	   void setRoot(Node*);
	   void inorder(Node*);
	   void postorder(Node*);
	   void preorder(Node*);
	   void makeListEmpty();
};