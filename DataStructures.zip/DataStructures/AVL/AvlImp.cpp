#include"AVL.h"
Jewel::Jewel()
{
    jewelId=0;
	strcpy(design,"null");
	costPerGram=0;
	gst=0.0;
}
Jewel::Jewel(int id,char des[],int cpg,float gs)
{
	jewelId=id;
	strcpy(design,des);
	costPerGram=cpg;
	gst=gs;
}
Jewel::Jewel(const Jewel &j)
{
	jewelId=j.jewelId;
	strcpy(design,j.design);
	costPerGram=j.costPerGram;
	gst=j.gst;
}
Jewel::Jewel(int c)
{
	jewelId=0;
	strcpy(design,"null");
	costPerGram=c;
	gst=0.0;
}
Jewel Jewel::operator=(Jewel j)
{
	jewelId=j.jewelId;
	strcpy(design,j.design);
	costPerGram=j.costPerGram;
	gst=j.gst;
	return *this;
}
Jewel Jewel::operator=(int x)
{
	jewelId=x;
	strcpy(design,"null");
	costPerGram=x;
	gst=(float)x;
	return *this;
}
bool Jewel::operator==(Jewel j)
{
	return jewelId==j.jewelId;
}
bool Jewel::operator!=(Jewel j)
{
	return !(*this==j);
}
bool Jewel::operator>(Jewel j)
{
	return jewelId>j.jewelId;
}
bool Jewel::operator<(Jewel j)
{
	return jewelId<j.jewelId;
}
istream& operator>>(istream &myin,Jewel &j)
{
	cout<<"\nEnter Jewel Id: ";
	myin>>j.jewelId;
	cout<<"\nEnter Jewel Design: ";
	myin>>j.design;
	cout<<"\nEnter The Jewel Gst: ";
	myin>>j.gst;
	cout<<"\nEnter The CostPerGram: ";
	myin>>j.costPerGram;
	return myin;
}
ostream& operator<<(ostream& myout,Jewel &j)
{
	myout<<"\nJewel: "<<j.jewelId<<"\tDesign: "<<j.design<<"\tCostPerGram: "<<j.costPerGram<<"\tGst: "<<j.gst;
	return myout;
}
Node::Node()
{
	height=0;
	data=-1;
	left=NULL;
	right=NULL;
}
Node::Node(int h,Jewel j,Node *l,Node *r)
{
	height=h;
	data=j;
	left=l;
	right=r;
}
Node::Node(const Node &n)
{
	height=n.height;
	data=n.data;
	left=n.left;
	right=n.right;
}
Node::~Node()
{
	delete right;
	delete left;
}
AVL_Tree::AVL_Tree()
{
	root=NULL;
}
AVL_Tree::AVL_Tree(Node *n)
{
	root=n;
}
AVL_Tree::AVL_Tree(const AVL_Tree &t)
{
	root=t.root;
}
AVL_Tree::~AVL_Tree()
{
	delete root;
}
int AVL_Tree::height(Node *node)
{
	if(node==NULL)
	   return -1;
	return node->height;
}
int AVL_Tree::findBF(Node *node)
{
	if(node==NULL)
	   return -1;
	return (height(node->left)-height(node->right));
}
int AVL_Tree::isEmpty()
{
	return root==NULL;
}
int AVL_Tree::max(int height1,int height2)
{
	if(height1>height2)
	   return  height1;
	else if(height1<height2)
	   return height2;
	return height1;
}
Node* AVL_Tree::LLRotate(Node *topNode)
{
	Node *centreNode=topNode->left;
	Node *temp=centreNode->right;
	centreNode->right=topNode;
	topNode->left=temp;
	topNode->height=max(height(topNode->left),height(topNode->right))+1;
	centreNode->height=max(height(centreNode->left),height(centreNode->right))+1;
	return centreNode;
}
Node* AVL_Tree::RRRotate(Node *topNode)
{
	Node *centreNode=topNode->right;
	Node *temp=centreNode->left;
    centreNode->left=topNode;
	topNode->right=temp;
	topNode->height=max(height(topNode->left),height(topNode->right))+1;
	centreNode->height=max(height(centreNode->left),height(centreNode->right))+1;
	return centreNode;
}
Node* AVL_Tree::LRRotate(Node *topNode)
{
	topNode->left=RRRotate(topNode->left);
	return LLRotate(topNode);
}
Node* AVL_Tree::RLRotate(Node *topNode)
{
    topNode->right=LLRotate(topNode->right);
	return RRRotate(topNode);
}
void AVL_Tree::inorder(Node* temp)
{
	if(temp!=NULL)
	{
		inorder(temp->left);
		cout<<temp->data;
		inorder(temp->right);
	}
}
void AVL_Tree::preorder(Node* temp)
{
	if(temp!=NULL)
	{
		cout<<temp->data;
		preorder(temp->left);
		preorder(temp->right);
	}
}
void AVL_Tree::postorder(Node* temp)
{
	if(temp!=NULL)
	{
		postorder(temp->left);
		postorder(temp->right);
		cout<<temp->data;
	}
}
Node* AVL_Tree::getRoot()
{
	return root;
}
void AVL_Tree::setRoot(Node *n)
{
	root=n;
}
Node* AVL_Tree::insert(Node *temp,Node *newnode)
{
	if(temp==NULL)
	{
		root=newnode;
		return root;
	}
	else 
	{
		if(temp->data>newnode->data)
		{
			if(temp->left==NULL)
			{
			  temp->left=newnode;
			}
			else
			{
				insert(temp->left,newnode);
			}
		}
		else if(temp->data<newnode->data)
		{
			if(temp->right==NULL)
			{
				temp->right=newnode;
			}
			else
			{
				insert(temp->right,newnode);
			}
		}
		else
		{
			return NULL;
		}
	}
	temp->height=max(height(temp->left),height(temp->right))+1;
	int balance=findBF(temp);
	if(balance<-1||balance>1)
	{
		if(newnode->data>temp->left->data)
		       return LRRotate(temp);
	    else if(newnode->data<temp->left->data)
		       return LLRotate(temp);
	    else if(newnode->data>temp->right->data)
		       return RRRotate(temp);
	    else 
		     return RLRotate(temp);
	}
	return temp;
}
void AVL_Tree::makeListEmpty()
{
	   setRoot(NULL);
}
Jewel AVL_Tree::search(Jewel key)
{
	Node *temp=root;
	while(temp!=NULL)
	{
		if(temp->data>key)
		   temp=temp->left;
		else if(temp->data<key)
		   temp=temp->right;
		else
		   return temp->data;
	}
	Jewel test;
	return test;
	}
