#include<string.h>
#include<iostream>
using namespace std;
class Jewel
{
	public:
	      Jewel();
	      Jewel(int,float,char*,int);
	      Jewel operator=(Jewel);//Assignment operator to assign object
	      Jewel operator=(int);//Assignment operator to assign default value
	      bool operator==(Jewel);//Equal to operator
	      Jewel(Jewel const&);
	      bool operator!=(Jewel);//Not Equal To Operator
	      friend istream& operator>>(istream &,Jewel &);
	      friend ostream& operator<<(ostream &,Jewel &);
		  int getId();
	      friend class Node;
	private:
	       int id;
	       float gst;
	       char design[20];
	       int gramPerCost;
};
class Node
{
    private:	
	Jewel data;
	Node *next;//Self Referencing Pointer Variable
    public:
	Node();
	Node(Jewel,Node*);
	Node(const Node&);
	~Node();
	friend class L_List;
};
class L_List
{
     private:
        Node *first;
     public:
        L_List();
        L_List(Node*);
	L_List(const L_List&);
	~L_List();
	int isEmpty();
	int insertAtFirst(Node*);
	int insertAtLast(Node*);
	int insertAtGivenPosition(int,Node*);
	Jewel deleteAtFirst();
	Jewel deleteAtLast();
	Jewel search(int);
	int makeListEmpty();
	Jewel deleteAtGivenPosition(int);
	int display();
	int displayInReverseOrder();
	int getSize();
	Jewel deleteAfterGivenElement(Jewel);
	Jewel deleteBeforeGivenElement(Jewel);

	       
};
