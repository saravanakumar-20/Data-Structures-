#include "sing.h"
int main()
{
	cout<<"\n*********Singly Linked List*********\n";
	int choice;
	L_List l1;
	do
	{
		cout<<"\nMenu: \n";
		cout<<"\n1.To Check Emptiness...";
		cout<<"\n2.To insert At First...";
		cout<<"\n3.To Insert At Last...";
		cout<<"\n4.To Insert At Given Position...";
		cout<<"\n5.To Delete First Element...";
		cout<<"\n6.To Delete Last Element...";
		cout<<"\n7.To Make The List Empty...";
		cout<<"\n8.Display All...";
		cout<<"\n9.DeleteAtGivenPosition...";
		cout<<"\n10.To Display In ReverseOrder...";
		cout<<"\n11.To Delete The Data After Given Input Data...";
		cout<<"\n12.To Delete The Data Before Given Input Data...";
		cout<<"\n13.To Search By Id...";
		cout<<"\n14.Exit\n";
		cout<<"\nEnter Your Choice: ";
		cin>>choice;
		if(choice==1)
		{
			cout<<"\n-------------------";
			cout<<"\nYou Have Pressed 1!";
			cout<<"\n-------------------\n";
			if(l1.isEmpty())
				cout<<"\nYes List Is Empty!\n";
			else
				cout<<"\nNo List Contain Some Datas!\n";
		}
		else if(choice==2)
		{
			cout<<"\n-------------------";
			cout<<"\nYou Have Pressed 2!";
			cout<<"\n-------------------\n";
			cout<<"\nEnter The Data To Insert: \n";
			Jewel j;
		        cin>>j;
		        Node *newnode=new Node(j,NULL);//creating new node
		        l1.insertAtFirst(newnode);
			cout<<"\nInsertion Successful!\n";
		}
		else if(choice==3)
		{
                        cout<<"\n-------------------";
			cout<<"\nYou Have Pressed 3!";
			cout<<"\n-------------------";
			cout<<"\nEnter The Data To Insert: \n";
			Jewel j;
			cin>>j;
			Node *newnode=new Node(j,NULL);//creating new node
			l1.insertAtLast(newnode);
			cout<<"\nInsertion successful!\n";
		}
		else if(choice==4)
		{
			cout<<"\n-------------------";
			cout<<"\nYou Have Pressed 4!";
			cout<<"\n-------------------";
			cout<<"\nEnter The Position: ";
			int pos;
			cin>>pos;
			cout<<"\nEnter The Data To Insert: \n";
			Jewel j;
		        cin>>j;
		        Node *newnode=new Node(j,NULL);//creating new node
		        int cases=l1.insertAtGivenPosition(pos,newnode);
			if(cases==1)
				cout<<"\nInsertion Successful!\n";
			else if(cases==0)
				cout<<"\nAs List Is Empty Position Should Be 1 But "<<pos<<" as Position Is given!\n" ;
			else
				cout<<"\nInvalid Position!\n";
		      	
		}
		else if(choice==8)
		{
			cout<<"\n------------------";
			cout<<"\nYou Have Pressed 8";
			cout<<"\n------------------";
			if(!l1.display())
			   cout<<"\nNothing There To Display!\n";
		}
		else if(choice==5)
		{
			cout<<"\n------------------";
			cout<<"\nYou Have Pressed 5";
			cout<<"\n------------------";
			Jewel cases=l1.deleteAtFirst();
			Jewel test;
			if(cases!=test)
				cout<<"\nDeleted Data: \n"<<cases;
			else
				cout<<"\nDeletion Unsuccessful! As The List Is Empty\n";
		}
		else if(choice==6)
		{
			cout<<"\n------------------";
			cout<<"\nYou Have Pressed 6";
			cout<<"\n------------------";
			Jewel cases= l1.deleteAtLast();
			Jewel test;
			if(cases!=test)
				cout<<"\nDeleted Data: \n"<<cases;
			else 
				cout<<"\nDeletion Unsuccessful! As The List Is Empty\n";
		}
		else if(choice==7)
		{
			cout<<"\n------------------";
			cout<<"\nYou Have Pressed 7";
			cout<<"\n------------------";
			if(l1.makeListEmpty())
				cout<<"\nList was Empty Now!\n";
			else
			        cout<<"\nList Is Already Empty!\n";	
		}
		else if(choice==13)
		{
			int id;
			cout<<"\nEnter The Id To Search: ";
            cin>>id;
			if(!l1.isEmpty())
			{
             Jewel cases=l1.search(id);
			 Jewel test;
			 if(cases!=test)
			    cout<<"\nThe Data You Are Looking For Is:\n"<<cases;
		     else
			    cout<<"\nData Not Present\n";
			}			 
			else
			   cout<<"\nList Is Empty\n";
		}
		else if(choice==9)
		{
			cout<<"\n-----------------";
			cout<<"\nYou Have Chosen 9";
		    cout<<"\n-----------------";
			int pos;
			cout<<"\n\nEnter The Position: ";
			cin>>pos;
			if(!l1.isEmpty())
			{
			 Jewel test;
			 Jewel ans=l1.deleteAtGivenPosition(pos);
		     if(ans!=test)	
			  cout<<"\nDeleted Data:\n"<<ans;
			 else 
           	  cout<<"\nInvalid Position!\n";
			}
			else
			  cout<<"\nList Is Empty!\n";
		}
		else if(choice==10)
		{
			cout<<"\n-------------------";
			cout<<"\nYou Have Pressed 10";
			cout<<"\n-------------------";
			if(!l1.displayInReverseOrder())
				cout<<"\nList Is Empty Nothing Here To Display!\n";
		}
		else if(choice==11)
		{
			cout<<"\n-------------------";
			cout<<"\nYou Have Pressed 11";
			cout<<"\n-------------------";
			Jewel j;
			cout<<"\nEnter The Data To Do Deletion After That Data: ";
			cin>>j;
			Jewel test;
			Jewel cases=l1.deleteAfterGivenElement(j);
		if(!l1.isEmpty())
		{
			if(cases!=test)
				cout<<"\nDeleted Data: "<<cases;
			else 
				cout<<"\nDeletion Unsuccessful\n";
		}
			else
				cout<<"\nList Is Empty\n";

		}
		else if(choice==12)
		{
			cout<<"\n-------------------";
			cout<<"\nYou Have Pressed 12";
			cout<<"\n-------------------";
			cout<<"\nEnter The Data To Do Deletion Bofore Given Data";
			Jewel j;
			cin>>j;
			Jewel cases=l1.deleteBeforeGivenElement(j);
		    Jewel test;
		if(!l1.isEmpty())
		{
			if(cases!=test)
				cout<<"\nDeleted Data: \n"<<cases;
			else 
				cout<<"\nDeletion UnSuccessful\n";
		}
			else
				cout<<"\nList Is Empty\n";
		}
                else if(choice==14)
			break;


        }while(choice!=14);
}
