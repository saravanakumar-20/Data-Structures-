#include "sing.h"
Jewel::Jewel()
{
	strcpy(design,"");
	gst=0.0;
	id=0;
	gramPerCost=0;
}
Jewel::Jewel(int id,float gst,char* des,int gpc)
{
	id=id;
	gst=gst;
	strcpy(design,des);
	gramPerCost=gpc;
}
Jewel::Jewel(Jewel const &j)
{
       id=j.id;
       gst=j.gst;
       strcpy(design,j.design);
       gramPerCost=j.gramPerCost;
}
Jewel Jewel::operator=(Jewel j)
{
       id=j.id;
       gst=j.gst;
       strcpy(design,j.design);
       gramPerCost=j.gramPerCost;
       return *this;
}
int Jewel::getId()
{
	return id;
}
Jewel Jewel::operator=(int x)
{
	id=x;
	gst=0.0;
	strcpy(design,"null");
	gramPerCost=x;
	return *this;
}
bool Jewel::operator==(Jewel j)
{
	if((id==j.id)&&(gst==j.gst)&&((strcmp(design,j.design))==0)&&(gramPerCost==j.gramPerCost))
		return 1;
	return 0;
}
ostream& operator<<(ostream &myout,Jewel &j)
{
	cout<<"\nJewel Id: ";
	myout<<j.id;
	cout<<"\nJewel Design: ";
	myout<<j.design;
	cout<<"\nJewel Gst: ";
	myout<<j.gst;
	cout<<"\nCost Per Gram: ";
	myout<<j.gramPerCost;
	cout<<"\n";
        return myout;
}
istream& operator>>(istream &myin,Jewel &j)
{
	cout<<"\nEnter Jewel Id: ";
	myin>>j.id;
	cout<<"\nEnter Jewel Design: ";
	myin>>j.design;
	cout<<"\nEnter Jewel Gst: ";
	myin>>j.gst;
	cout<<"\nEnter Cost Of One Gram: ";
	myin>>j.gramPerCost;
	cout<<"\n";
	return myin;
}
bool Jewel::operator!=(Jewel j)
{
	if(*this==j)
		return 0;
	return 1;
}
Node::Node()
{
	next=NULL;
}
Node::Node(Jewel dat,Node *nex)
{
	data=dat;
	next=nex;
}
Node::Node(const Node &n1)
{
	data=n1.data;
	next=n1.next;
}
Node::~Node()
{
	delete next;
}
L_List::L_List()
{
	first=NULL;
}
L_List::L_List(Node *firs)
{
	first=firs;
}
L_List::L_List(const L_List &l)
{
	first=l.first;
}
L_List::~L_List()
{
	delete first;
	first=NULL;
}
int L_List::isEmpty()
{
	return first==NULL;
}
int L_List::insertAtFirst(Node *newnode)
{
	if(!isEmpty())
	{
		newnode->next=first;
		first=newnode;
	}
	else
		first=newnode;
	return 1;
}
int L_List::insertAtLast(Node *newnode)
{
	if(isEmpty())
		first=newnode;
	else
	{
		Node *temp=first;
		while(temp->next!=NULL)
		{
			temp=temp->next;
		}
		temp->next=newnode;
	}
	return 1;
}
Jewel L_List::deleteAtFirst()
{
	if(isEmpty())
	{
		Jewel test;
		return test;
	}
	else
	{
		Node *temp;
		temp=first;
		Jewel ret=temp->data;
		first=first->next;
		return ret;
	}
}
Jewel L_List::deleteAtLast()
{
	if(isEmpty())
	{
		Jewel test;
		return test;
	}
	else
	{
		Node *temp=first;
		if(temp->next==NULL)
	        {
                   first=NULL;
		}
		else
		{
		 Node *prev;
		 while(temp->next!=NULL)
		 {
			prev=temp;
			temp=temp->next;
		 }
		 prev->next=NULL;
		}
		return temp->data;
	}
}
int L_List::insertAtGivenPosition(int pos,Node *newnode)
{
	if(isEmpty())
	{
		if(pos==1)
		{
			first=newnode;
			return 1;
		}
		return 0;
	}
	else
	{
		Node *temp=first;
		int cnt=1;
		while((temp->next!=NULL)&&(cnt!=pos-1))
		{
			temp=temp->next;
			cnt++;
		}
		if(cnt==pos-1)
		{
			newnode->next=temp->next;
			temp->next=newnode;
			return 1;
		}
		return  -1;
	}
}
int L_List::makeListEmpty()
{
  if(!isEmpty())
  {
	  Node *temp=first;
	  while(!isEmpty())
	  {
		 delete temp;
		 first=first->next;
		 Node *temp=first;;
	  }
	  return 1;
  }
  return 0;  
}
Jewel L_List::search(int idi)
{
	Node *temp=first;
	while(temp!=NULL)
	{
		if(temp->data.getId()==idi)
		   return temp->data;
		temp=temp->next;
	}
	Jewel test;
	return test;
}
int L_List::display()
{
	if(!isEmpty())
	{
	   Node *temp=first;
	   int i=1;
	   while(temp->next!=NULL)
	   {
		   cout<<"\nData "<<i<<":\n";
		   cout<<temp->data;
		   temp=temp->next;
		   i++;
	   }
	   cout<<"\nData "<<i<<":\n";
	   cout<<temp->data;
	   return 1;
	}
	return 0;
}
int L_List::displayInReverseOrder()
{
	if(!isEmpty())
	{
	  int cnt=getSize();
	  int j=0;
	  Jewel l[cnt];
	  Node *temp=first;
	  while(temp!=NULL)
	  {
		  l[j]=temp->data;
		  j++;
		  temp=temp->next;
	  }
	  j=0;
	  cout<<"\nDatas: \n";
	  for(int i=cnt-1;i>=0;i--)
	  {
		  cout<<"\nData "<<j+1<<":\n";
		  cout<<l[i];
		  j++;
	  }
	  return 1;
	}
	return 0;
}
int L_List::getSize()
{
	Node *temp=first;
	int cnt=0;
	while(temp!=NULL)
	{
            temp=temp->next;
	    cnt++;
	}
	return cnt;

}
Jewel L_List::deleteAtGivenPosition(int pos)
{
	     if(pos!=1)
	     {
		  int cnt=1;
		  Node *temp=first;
		  Node *prev; 
		  while((temp->next!=NULL)&&(cnt!=pos))
		  {
			prev=temp;
			temp=temp->next;
			cnt++;
		  }
		  if(cnt==pos)
		  {
		   prev->next=temp->next;
		   return temp->data;
		  }
		  else
		  {
			  Jewel test;
			  return test;
		  }
		 }
	     else
	     {
		     Node *temp=first;
		     first=first->next;
			 return temp->data;
	     }
}
Jewel L_List::deleteAfterGivenElement(Jewel j)
{
		Node *temp=first;
		Node *aftertemp=temp->next;
		while((temp->data!=j)&&(temp->next!=NULL))
		{
			temp=temp->next;
			aftertemp=temp->next;
		}
		if((temp->next!=NULL)&&(temp->data)==j)
		{
			temp->next=aftertemp->next;
			return aftertemp->data;
		}
		Jewel test;
		return test;
}
Jewel L_List::deleteBeforeGivenElement(Jewel j)
{
		Jewel test;
		Node *temp=first;
		if(getSize()==1)
		{
			  return test;
		}
		else if(getSize()==2)
		{
		   if(temp->next->data==j)
		   {
			   Jewel ret=first->data;
			   first=first->next;
			   return ret;
		   }
		   return test;
		}
		else
		{
			Node *prevbefore;
			Node *previous;
			while(temp->next!=NULL&&temp->data!=j)
			{
				prevbefore=previous;
				previous=temp;
				temp=temp->next;
			}
		        if(temp->data==j)
			{
				Jewel ret=previous->data;
				prevbefore->next=temp;
				return ret;
			}
			return test;
		}
}


