#include<iostream>
using namespace std;
#include<string.h>
class Jewel
{
	private:
	  int id;
	  int cost_per_gram;
	  char design[20];
	  float gst;
	public:
	  Jewel();
	  Jewel operator=(int);
	  void get_data();
	  void display_data();
	  Jewel operator=(Jewel);
	  bool operator==(Jewel);
	  int get_id();
};
class Graph
{
 public:
Graph(int);
~Graph();
void getData();
void createGraph();
void displayAll();
void performDFS();
void DFS(int);
void showVertexData(int);
void printAdjacent();
void implementConnectedComponent();
 private:
Jewel *vertices;
int noOfVertices;
bool *visited;
int **adjMatrix;
};