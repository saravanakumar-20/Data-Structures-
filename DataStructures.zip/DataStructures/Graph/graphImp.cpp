#include"graph.h"
Jewel::Jewel()
{
	id=0;
	strcpy(design,"null");
	cost_per_gram=0;
	gst=0.0;
}
Jewel Jewel::operator=(Jewel j)
{
	 id=j.id;
	 cost_per_gram=j.cost_per_gram;
	 gst=j.gst;
	 strcpy(design,j.design);
	 return *this;
}
bool Jewel::operator==(Jewel j)
{
	return j.id==id;
}
Jewel Jewel::operator=(int x)
{
	id=x;
	cost_per_gram=x;
	gst=0.0;
	strcpy(design,"null");
	return *this;
}
void Jewel::get_data()
{
	cout<<"\nEnter Jewel_id:";
	cin>>id;
	cout<<"\nEnter Jewel_design: ";
	cin>>design;
	cout<<"\nEnter Jewel_gst: ";
	cin>>gst;
	cout<<"\nEnter cost_per_gram: ";
	cin>>cost_per_gram;
}
void Jewel::display_data()
{
	cout<<"\nJewel_id: "<<id;
	cout<<"\nJewel_design: "<<design;
	cout<<"\nJewel_gst: "<<gst;
	cout<<"\ncost_per_gram: "<<cost_per_gram;
	cout<<"\n";
}
int Jewel::get_id()
{
	return id;
}
Graph::Graph(int n)
{
 noOfVertices = n;
 vertices = new Jewel[noOfVertices];
 adjMatrix = new int*[noOfVertices];
 for( int i=0; i<noOfVertices; i++ )
adjMatrix[i] = new int[noOfVertices];
 for( int i=0;i<noOfVertices ; i++)
for( int j=0; j<noOfVertices ; j++)
adjMatrix[i][j] = 0;
}
Graph::~Graph()
{
}
void Graph::getData()
{
 Jewel j;
 for(int i=0;i<noOfVertices;i++)
 {
    j.get_data();
   vertices[i]= j;
 }
}
void Graph::createGraph()
{
 int edge,v,w;
 cout<<"\n Enter no of edges in the graph : ";
 cin>>edge;
 for(int i=0;i<edge;i++)
 {
 cout<<"\n Enter the adjacent vertices\n";
 cout<<"\n Enter v : ";
 cin>>v;
 cout<<"\n Enter w : ";
 cin>>w;
 adjMatrix[v][w] =1;
 adjMatrix[w][v] =1;
 }
}
void Graph :: displayAll()
{
 for(int i=0;i<noOfVertices;i++)
 {
   vertices[i].display_data();
 }
}
void Graph :: showVertexData(int i)
{
 vertices[i].display_data();
}
void Graph::performDFS()
{
 visited = new bool[noOfVertices];
 for( int i=0; i<noOfVertices; i++)
visited[i] = false;
 for( int i=0; i<noOfVertices; i++)
 {
if(!visited[i])
DFS(i);
 }
}
void Graph::DFS(int i)
{
 showVertexData(i);
 visited[i] = true;
 for( int j=0; j<noOfVertices; j++)
 {
 if( adjMatrix[i][j] == 1)
 {
if(!visited[j])
 DFS(j);
 }
 }
}
void Graph::printAdjacent()
{
 for(int i=0;i<noOfVertices;i++)
cout<<"\t"<<i;
 cout<<"\n";
 for(int i=0; i<noOfVertices ; i++)
cout<<"________";
 cout<<"\n";
 for( int i=0;i<noOfVertices ; i++)
 {
 cout<<i<<" |\t";
 for( int j=0; j<noOfVertices ; j++)
cout<<adjMatrix[i][j]<<"\t";
 cout<<"\n";
 }
}
void Graph::implementConnectedComponent()
{
 visited = new bool[noOfVertices];
 for( int i=0; i<noOfVertices; i++)
visited[i] = false;
 int count = 0;
 for( int i=0; i<noOfVertices; i++)
 {
 if(!visited[i])
 {
cout<<"Connected Component "<<++count<<endl;
DFS(i);
 }
 }
}