#include"StackADT.h"
Jewel::Jewel()
{
	id=0;
        strcpy(design,"null");
	costPerGram=0;
	gst=0.0;
}
/*Jewel::Jewel(const Jewel &j)
{
	id=j.id;
	strcpy(design,j.design);
	costPerGram=j.costPerGram;
	gst=j.gst;
}*/
Jewel Jewel::operator=(int x)
{
	id=x;
	strcpy(design,"-1");
	costPerGram=x;
	gst=float(x);
	return *this;
}
Jewel Jewel::operator=(Jewel j)
{
	strcpy(design,j.design);
	id=j.id;
	gst=j.gst;
	costPerGram=j.costPerGram;
	return *this;
}
istream& operator>>(istream &myin,Jewel &j)
{
	cout<<"Enter Id: ";
	myin>>j.id;
	cout<<"\nEnter Design: ";
	myin>>j.design;
	cout<<"\nEnter Gst: ";
	myin>>j.gst;
	cout<<"\nEnter Cost Of One Gram: ";
	myin>>j.costPerGram;
	return myin;
}
ostream& operator<<(ostream &myout,Jewel &j)
{
	myout<<"\nId: "<<j.id;
	myout<<"\tDesign: "<<j.design;
	myout<<"\tGst: "<<j.gst;
	myout<<"\tCostPerGram: "<<j.costPerGram<<"\n";
	return myout;
}
Stack_ADT::Stack_ADT()
{
	capacity=10;
	top=-1;
	JewelArray = new Jewel[capacity];
	for(int i=0;i<capacity;i++)
		JewelArray[i]=-1;
}
Stack_ADT::Stack_ADT(const Stack_ADT &s)
{
	capacity=s.capacity;
	top=s.top;
	JewelArray=new Jewel[capacity];
	for(int i=0;i<=top;i++)
		JewelArray[i]=s.JewelArray[i];
}
Stack_ADT::Stack_ADT(int c)
{
        capacity=c;
	top=-1;
	JewelArray=new Jewel[capacity];
}
int Stack_ADT::isFull()
{
	if(top==capacity-1)
		return 1;
	return 0;
}
int Stack_ADT::isEmpty()
{
	if(top==-1)
		return 1;
	return 0;
}
int Stack_ADT::push(Jewel j)
{
	if(!isFull())
	{
		top+=1;
		JewelArray[top]=j;
		return 1;
	}
	return 0;
}
Jewel Stack_ADT::pop()
{
	Jewel j=JewelArray[top];
	JewelArray[top]=-1;
	top-=1;
	return j;
}
int Stack_ADT::getSize()
{
	return top+1;
}
int Stack_ADT::displayStack()
{
	if(!isEmpty())
	{
	  cout<<"\n*******Jewels Available*******\n\n";
          for(int i=0;i<=top;i++)
	  {
		  cout<<"\nData "<<i+1<<":";
		  cout<<JewelArray[i];
	  }
	  cout<<"\n\n";
	  return 1;
	}
	return 0;
}
int Stack_ADT::displayPeakData()
{
	if(!isEmpty())
	{
		cout<<"\n\n******PeakData*******\n\n";
		cout<<"\n"<<JewelArray[top]<<"\n\n";
		return 1;
	} 
	return 0;
}
int Stack_ADT::makeStackEmpty()
{
	if(isEmpty())
		return 0;
	else
	{
          while(!isEmpty())
	  {
		  pop();
	  }
	}
	return 1;
}

