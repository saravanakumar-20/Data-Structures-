#include"StackADT.h"
int main()
{
	cout<<"\n*********StackADT Implementation Using Array*********\n\n";
	cout<<"\nEnter Capacity Of Store: ";
	int cap;
	cin>>cap;
	int choice;
	Stack_ADT S(cap);
	Jewel j;
	do
	{
	    cout<<"\n            ----          \n";
	    cout<<"\n            Menu          \n";
	    cout<<"\n            ----          \n";
	    cout<<"\n1.Add A Jewel";
	    cout<<"\n2.Buy A Jewel";
	    cout<<"\n3.Display All The Jewels Available";
	    cout<<"\n4.Get The Total Number Of Jewels";
	    cout<<"\n5.Get The Recently Added Jewel";
	    cout<<"\n6.Buy All The Jewels";
	    cout<<"\n7.Check Whether The Store Is Full";
	    cout<<"\n8.Check Whether the Store Is Empty";
	    cout<<"\n9.Exit";
	    cout<<"\n\nEnter Your choice: ";
	    cin>>choice;
	    if(choice==1)
	    {
		    Jewel j;
		    cin>>j;
		    int cases=S.push(j);
		    if(cases==1)
			    cout<<"\nSuccessfully Added!";
		    else
			    cout<<"\nThe Store IS Full Adding Not Possible!";
	    }
	    else if(choice==2)
	    {
		    if(S.isEmpty())
			   cout<<"\nAs The Store Is Empty So No Jewel There To Buy!";
		   else
		   {
			   Jewel j=S.pop();
		           cout<<"\n     Bought Jewel  ";
		           cout<<j;
		   }
	    }
	    else if(choice==3)
	    {
		    if(!S.displayStack())
			    cout<<"\nStore Is Empty Nothing To Display!";
	    }
	    else if(choice==4)
	    {
		   cout<<"\nTotal Number Of Jewels Available In The Store: "<<S.getSize(); 
	    }
	    else if(choice==5)
	    {
		    if(!S.displayPeakData())
			    cout<<"\nStore Being Empty..No Recently Added Jewel!\n";
	    }
	    else if(choice==6)
	    {
		    if(S.makeStackEmpty())
			    cout<<"\nAll The Jewels Were Bought Successfully!\n";
		    else
			    cout<<"\nStore Is Already Empty!\n";
	    }
	    else if(choice==7)
	    {
		    if(S.isFull())
			    cout<<"\nYes Store Is Full!\n";
		    else
			    cout<<"\nNo Store Is Not Full!\n";
	    }
	    else if(choice==8)
	    {
		    if(S.isEmpty())
			    cout<<"\nYes Store Is Empty!\n";
		    else
			    cout<<"\nNo Store Is Not Empty!\n";
		}
	    else if(choice==9)
		    break;
	}while(choice!=9);

}
