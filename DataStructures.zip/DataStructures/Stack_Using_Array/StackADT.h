#include<iostream>
#include<string.h>
using namespace std;
class Jewel
{
	public:
	      Jewel();
	      //Jewel(const Jewel&);
	      bool operator==(Jewel);
	      Jewel operator=(Jewel);
	      Jewel operator=(int);
	      friend istream& operator>>(istream&,Jewel&);
	      friend ostream& operator<<(ostream&,Jewel&);
        private:
	       int id;
	       int costPerGram;
	       float gst;
	       char design[20];

};
class Stack_ADT 
{
	private:
	       Jewel *JewelArray;
	       int capacity;
	       int top;
	public:
	      Stack_ADT();
	      Stack_ADT(int);
              Stack_ADT(const Stack_ADT&);
	      int isFull();
	      int isEmpty();
	      int push(Jewel);
	      Jewel pop();
	      int displayPeakData();
	      int getSize();
	      int makeStackEmpty();
	      int displayStack(); 
};
