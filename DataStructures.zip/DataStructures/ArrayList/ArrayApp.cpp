#include "Array.h"
int main()
{
	cout<<"\n*********LIST ADT IMPLEMENTATION USING ARRAY*********";
	cout<<"\n\nEnter The Capacity: ";
	int c;
	cin>>c;
	cout<<"\nEnter Size: ";
	int s;
	cin>>s;
	Jewel j[s];
	if(s!=0)
		cout<<"\nEnter Datas: \n";
	for(int i=0;i<s;i++)
	{
		cout<<"\nEnter Data "<<i+1<<":";
		cin>>j[i];
	}
	cout<<"\nGot The Sufficient Information!";
	ArrayList A1(j,c,s);
	int choice=0;
	while(choice!=16)
	{
		cout<<"\n\nMenu:"; 
		cout<<"\n===============================";
		cout<<"\n1.Display All                 ||";
		cout<<"\n2.InsertAtFirst               ||";
		cout<<"\n3.InsertAtLast                ||";
		cout<<"\n4.Check Fullness              ||";
		cout<<"\n5.Check Emptyness             ||";
		cout<<"\n6.InsertAtGivenPosition       ||";
		cout<<"\n7.DeleteAtGivenPosition       ||";
		cout<<"\n8.DeleteAtFirst               ||";
		cout<<"\n9.DeleteAtLast                ||";
		cout<<"\n10.RetrieveElementAtGivenIndex||";
		cout<<"\n11.MakeListEmpty              ||";
		cout<<"\n12.SearchElement              ||";
		cout<<"\n13.SearchAtFirst              ||";
		cout<<"\n14.SearchAtLast               ||";
  		cout<<"\n15.DeleteByElement            ||";
		cout<<"\n16.Exit                       ||";
	    cout<<"\n===============================";
		cout<<"\nEnter Your Choice: ";
		cin>>choice;
		Jewel J;
		if(choice==1)
		{
			cout<<"\n----------------------------";
			cout<<"\nYou Have chosen Display All!";
			cout<<"\n----------------------------";
			if(!A1.display())
				cout<<"\n\nNothing To Display!";
		}
		else if(choice==15)
		{
			cout<<"\n-------------------------------";
			cout<<"\nYou Have Chosen DeleteByElement";
			cout<<"\n-------------------------------";
			if(!A1.isEmpty())
			{
				cout<<"\nEnter The Id To Delete The Data: ";
				int idi;
				cin>>idi;
				Jewel cases=A1.deleteByElement(idi);
				Jewel test;
			    if(!(cases==test))
				 cout<<"\nDeleted Data: \n"<<cases;
			    else 
			     cout<<"\nData Not Present With This Id\n";
			}
			else
			   cout<<"\nList Empty!\n";
				
		}
		else if(choice==2)
		{
			cout<<"\n------------------------------";
			cout<<"\nYou Have Chosen InsertAtFirst!";
			cout<<"\n------------------------------";
			cout<<"\nGive Essential Datas To do The Insertion!";
			cin>>J;
			if(A1.insertAtFirst(J))
			{
				cout<<"\n\nInsertion Successful!";
			}
			else
				cout<<"\n\nInsertion Not Possible As The List Is Full!";
		}
		else if(choice==3)
		{
			cout<<"\n-------------------------------";
			cout<<"\nYou Have Chosen Insert At Last!";
			cout<<"\n-------------------------------";
			cout<<"\nEnter The Essential Datas To Do The Insertion!";
			cin>>J;
			if(A1.insertAtLast(J))
			{
				cout<<"\n\nInsertion Successful!";
			}
			else
				cout<<"\n\nInsertion Not Possible As The List Is Full!";	
		}
		else if(choice==4)
		{
			cout<<"\n-------------------------";
			cout<<"\nYou Have Chosen Fullness!";
			cout<<"\n-------------------------";
			if(A1.isFull())
			        cout<<"\n\nYes List Is Full!";
			else
				cout<<"\n\nNo List Is Not Full!";
		}
		else if(choice==5)
		{
			cout<<"\n--------------------------";
			cout<<"\nYou Have Chosen Emptyness!";
			cout<<"\n--------------------------";
			if(A1.isEmpty())
				cout<<"\n\nYes List Is Empty!";
			else
				cout<<"\n\nNo List Is Not Empty!";
		}
		else if(choice==6)
		{
			cout<<"\n--------------------------------------";
			cout<<"\nYou Have Chosen InsertAtGivenPosition!";
			cout<<"\n--------------------------------------";
			cout<<"\nEnter The Position To Insert: ";
			int pos;
			cin>>pos;
			cout<<"\nEnter The Data: \n";
			cin>>J;
			int cases=A1.insertAtGivenPosition(pos,J);//cases to store failure and successful indications
			if(cases==0)
				cout<<"\nList Is Full Insertion Not Full!";
			else if(cases==1)
				cout<<"\nInsertion Successfull!";
			else if(cases==-1)
				cout<<"\nAs The List Is Empty! Position Should Be 1 But Invlalid Position Given...";
			else if(cases==-2)
				cout<<"\nInvalid Position!";
		}
		else if(choice==7)
		{
			cout<<"\n--------------------------------------";
			cout<<"\nYou Have Chosen deleteAtGivenPosition!";
			cout<<"\n--------------------------------------";
			cout<<"\nEnter The Position To Delete: ";
			int pos;
			cin>>pos;
			Jewel test;
			Jewel cases=A1.deleteAtGivenPosition(pos);//cases to store failure and successful indications
			if(!A1.isEmpty())
			{
			 if(!(cases==test))
				cout<<"\nDeleted Data:\n"<<cases;
			 else 
				cout<<"\nInvalid Position!";
			}
			 else 
				cout<<"\nDeletion Not Possible As The List Is Empty!";
		}
		else if(choice==8)
		{
			cout<<"\n------------------------------";
			cout<<"\nYou Have Chosen DeleteAtFirst!";
			cout<<"\n------------------------------";
			Jewel cases=A1.deleteAtFirst();//cases to store failure and successful indications
			Jewel test;
			if(!(cases==test))
				cout<<"\nDeleted Data:\n"<<cases;
			else
				cout<<"\nDeletion Not Successfull As The List Is Empty!";
		}
		else if(choice==9)
		{
			cout<<"\n-----------------------------";
			cout<<"\nYou Have chosen DeleteAtLast!";
			cout<<"\n-----------------------------";
			Jewel cases=A1.deleteAtLast();//cases to store failure and successful indications
			Jewel test;
			if(!(cases==test))
				cout<<"\nDeleted Data:\n"<<cases;
			else
				cout<<"\nDeletion Not Successfull!";
		}
		else if(choice==10)
	        {
			cout<<"\n--------------------------------------------";
			cout<<"\nYou Have Chosen RetrieveElementAtGivenIndex!";
			cout<<"\n--------------------------------------------";
                        int index;
			cout<<"\nEnter The Index To Retrieve: ";
			cin>>index;
			if(!A1.isEmpty())
		        {
  				if((A1.getSize()>index)&&(!(index<0)))
				{
					J=A1.retrieveElementAtGivenIndex(index);
					cout<<"\nRetrieved Object: \n";
					cout<<J;
				}
			       	else
					cout<<"\nInvalid Index!";
			}
			else
				cout<<"\nList Is Empty Retrievel Not Possible!";
		}
		else if(choice==11)
		{
			cout<<"\n------------------------------";
			cout<<"\nYou Have Chosen MakeListEmpty!";
			cout<<"\n------------------------------";
			int cases=A1.makeListEmpty();//cases to store failure and successful indications
			if(cases==1)
				cout<<"\nOperation Success!";
			else 
				cout<<"\nList Already Empty!";
			
		}
		else if(choice==12)
		{
			cout<<"\n------------------------------";
			cout<<"\nYou Have Chosen SearchElement!";
			cout<<"\n------------------------------";
			cout<<"\nEnter The Jewel Id To Get The Full Details: ";
			int id;
			cin>>id;
			Jewel J(id);
			Jewel test;
			Jewel cases=A1.searchElement(J);//cases to store failure and successful indications
		 if(!A1.isEmpty())
		 {
    		 if(!(cases==test))
				cout<<"\nThe Object You Are Looking For is:"<<cases;
			 else
				cout<<"\nNot Present!";
		 }
		 else
		     cout<<"\nOOPS!List Is Empty..\n";
		}
		else if(choice==13)
		{
			cout<<"\n------------------------------";
			cout<<"\nYou Have Chosen searchAtFirst!";
			cout<<"\n------------------------------";
		    cout<<"\nEnter The Jewel Id To Search: ";
			int id;
			cin>>id;
			Jewel J(id);
			Jewel test;
			Jewel cases=A1.searchAtFirst(J);//cases to store failure and successful indications
		 if(!A1.isEmpty())
		 {
			if(!(cases==test))
				cout<<"\nThe Object You Are Looking For Is:"<<cases;
			else 
				cout<<"\nObject Not Present At First Place!";
		 }
			else 				
				cout<<"\nAs List Is Empty No Possibility For The List To Have This Particular Object!";
		}
		else if(choice==14)
		{
			cout<<"\n-----------------------------";
			cout<<"\nYou Have Chosen SearchAtLast!";
			cout<<"\n-----------------------------";
			cout<<"\nEnter the Jewel Id To Search: ";
			int id;
			cin>>id;
			Jewel J(id); 
			Jewel test;
			Jewel ret=A1.searchAtLast(J);//cases to store failure and successful indications
		  if(!A1.isEmpty())
		  {
			if(!(ret==test))
				cout<<"\nThe Object You are Looking For Is: \n"<<ret;
			else 
				cout<<"\nObject Not Present At Last Place!";
		  }
			else
				cout<<"\nAs List Is Empty No Possibility For The List To Have This Particular Object!";
				
		}
		else if(choice==16)
		    break;
	    else 
		    cout<<"\nInvalid Input\n";
	}
}

