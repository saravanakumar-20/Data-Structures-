#include "Array.h"
Jewel::Jewel()
{
	id=0;
	strcpy(design,"null");
	gst=0.0;
	gramPerCost=0;
}
Jewel::Jewel(int i)
{
	id=i;
	gst=0.0;
	strcpy(design,"null");
	gramPerCost=0;
}
Jewel::Jewel(int id,float gst,char* des,int gpc)
{
	id=id;
	gst=gst;
	strcpy(design,des);
	gramPerCost=gpc;
}
int Jewel::getId()
{
	return id;
}
Jewel::Jewel(Jewel const &j)
{
       id=j.id;
       gst=j.gst;
       strcpy(design,j.design);
       gramPerCost=j.gramPerCost;
}
Jewel Jewel::operator=(Jewel j)
{
       id=j.id;
       gst=j.gst;
       strcpy(design,j.design);
       gramPerCost=j.gramPerCost;
       return *this;
}
Jewel Jewel::operator=(int x)
{
	id=x;
	gst=0.0;
	strcpy(design,"null");
	gramPerCost=x;
	return *this;
}
bool Jewel::operator==(Jewel j)
{
	if(id==j.id)
		return 1;
	return 0;
}
ostream& operator<<(ostream &myout,Jewel &j)
{
	cout<<"\nJewel Id: ";
	myout<<j.id;
	cout<<"\tJewel Gst: ";
	myout<<j.gst;
	cout<<"\tJewel Design: ";
	myout<<j.design;
	cout<<"\tCost Per Gram: ";
	myout<<j.gramPerCost;
	cout<<"\n";
    return myout;
}
istream& operator>>(istream &myin,Jewel &j)
{
	cout<<"\nEnter Jewel Id: ";
	myin>>j.id;
	cout<<"\nEnter Jewel Design: ";
	myin>>j.design;
	cout<<"\nEnter Jewel Gst: ";
	myin>>j.gst;
	cout<<"\nEnter Cost Of One Gram: ";
	myin>>j.gramPerCost;
	cout<<"\n";
	return myin;
}
ArrayList::ArrayList()
{
	capacity=10;
	size=0;
	JewelArray = new Jewel[capacity];
	for(int i=0;i<capacity;i++)
	{
            JewelArray[i]=-1;
	}
}
ArrayList::ArrayList(Jewel* j ,int cap,int siz)
{
	capacity=cap;
	size=siz;
	JewelArray = new Jewel[capacity];
	for(int i=0;i<size;i++)
	{
	    JewelArray[i]=j[i];
	}
	for(int i=size;i<capacity;i++)
		JewelArray[i]=-1;
}
ArrayList::ArrayList(ArrayList const &A)
{
	capacity=A.capacity;
	size=A.size;
	JewelArray = new Jewel[capacity];
	for(int i=0;i<size;i++)
	{
            JewelArray[i]=A.JewelArray[i];		
	}
}
ArrayList::~ArrayList()
{
	delete[] JewelArray;
}
int ArrayList::insertAtGivenPosition(int pos,Jewel j)
{
	if(!isFull())
	{
		if(isEmpty())
		{
			if(pos==1)
			{
                            JewelArray[0]=j;
			    size++;
			    return 1;
			}
			return -1;
		}
		else
		{
		    if((pos<=size+1)&&(!(pos<0)))
		      {

			for(int i=size;i>pos-1;i--)
			{
                             JewelArray[i]=JewelArray[i-1];
			}
			JewelArray[pos-1]=j;
			size++;
			return 1;
		      }
		    return -2;
		}
	}
	return 0;
}
Jewel ArrayList::deleteAtGivenPosition(int pos)
{
		if((pos<=size)&&(!(pos<=0)))
		{
			Jewel ret=JewelArray[pos-1];
			for(int i=pos-1;i<size-1;i++)
				JewelArray[i]=JewelArray[i+1];
                        JewelArray[size-1]=0;
                        size--;			
			return ret;
		}
		Jewel test;
		return test;
}
Jewel ArrayList::deleteByElement(int idi)
{
	int i;
	for( i=0;i<size;i++)
	{
	   if(JewelArray[i].getId()==idi)
	   {
		   break;
	   }
	}
	if(i==size)
	{
		Jewel test;
		return test;
	}
	Jewel ret=JewelArray[i];
    for(int j=i;j<size-1;j++)
	{
		JewelArray[i]=JewelArray[i+1];
		JewelArray[size-1]=0;
	}
	size--;
	return ret;
	
}
Jewel ArrayList::searchAtFirst(Jewel j)
{
		
		if(JewelArray[0]==j)
			return JewelArray[0];
		Jewel test;	
		return test;
	
}
Jewel ArrayList::searchAtLast(Jewel j)
{
	    
		if(JewelArray[size-1]==j)
			return JewelArray[size-1];
		Jewel test;
		return test;
}
Jewel ArrayList::retrieveElementAtGivenIndex(int index)
{
	return JewelArray[index];
}
int ArrayList::getSize()
{
	return size;
}
Jewel ArrayList::deleteAtFirst()
{
	if(!isEmpty())
	{
		Jewel ret=JewelArray[0];
		for(int i=0;i<size-1;i++)
			JewelArray[i]=JewelArray[i+1];
		JewelArray[size-1]=0;
		size--;
		return ret;
	}
	Jewel test;
	return test;
}
Jewel ArrayList::deleteAtLast()
{
	if(!isEmpty())
	{
		Jewel ret=JewelArray[size-1];
		JewelArray[size-1]=0;
		size--;
		return ret;
	}
	Jewel test;
	return test;
}
Jewel ArrayList::searchElement(Jewel j)
{
		for(int i=0;i<size;i++)
			if(JewelArray[i]==j)
			 return JewelArray[i];
	    Jewel test;
	    return test;
}
int ArrayList::makeListEmpty()
{
	if(!isEmpty())
	{
		while(!isEmpty())
		{
		  deleteAtFirst();
		}
		return 1;
	}
	return 0;
}
int ArrayList::display()
{
     if(!isEmpty())
     {
	cout<<"\ncapacity: ";
	cout<<capacity;
	cout<<"\nsize: ";
	cout<<size;
	cout<<"\nDatas: \n";
	for(int i=0;i<size;i++)
        {
	    cout<<"\nData "<<i+1<<":";
	    cout<<JewelArray[i];
	}
	return 1;
     }	
     return 0;

}
int ArrayList::isFull()
{
	if(size==capacity)
		return 1;
	return 0;
}
int ArrayList::isEmpty()
{
	if(size==0)
		return 1;
	return 0;
}
int ArrayList::insertAtLast(Jewel j)
{
	if(isFull())
		return 0;
	else
	{
		JewelArray[size]=j;
		size++;
		return 1;
	}	
}
int ArrayList::insertAtFirst(Jewel j)
{

	if(isFull())
	   return 0;
	else
	{
		if(isEmpty())
		{
			JewelArray[0]=j;
			size=1;
		}
		else
		{
			for(int i=size;i>0;i--)
			{
			  JewelArray[i]=JewelArray[i-1];
			}
			JewelArray[0]=j;
			size++;
		}
		return 1;
	}
	   
}
