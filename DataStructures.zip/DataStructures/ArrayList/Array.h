#include<string.h>
#include<iostream>
using namespace std;
class Jewel //Data Part As Object
{
	public:
	      Jewel();
	      Jewel(int,float,char*,int);
		  Jewel(int);
	      Jewel operator=(Jewel);//Assignment operator
	      Jewel operator=(int);//Assignment operator to assign default value(-1)
	      bool operator==(Jewel);//Equal to operator to compare objects
	      Jewel(Jewel const&);
		  int getId();
	      friend istream& operator>>(istream &,Jewel &);//To get input of data using cin
	      friend ostream& operator<<(ostream &,Jewel &);//To print object using cout
	private:
	       int id;
	       float gst;
	       char design[20];
	       int gramPerCost;

};
class ArrayList
{
    private:
	  Jewel *JewelArray;//Object array
	  int capacity;
	  int size;
    public:
	  ArrayList();
	  ArrayList(Jewel*,int,int);
	  ArrayList( ArrayList const&);
	  ~ArrayList();
	  Jewel searchAtFirst(Jewel);
	  Jewel searchAtLast(Jewel);
	  Jewel deleteByElement(int);
	  int isEmpty();
	  int isFull();
	  int insertAtFirst(Jewel);
	  int insertAtLast(Jewel);
	  int insertAtGivenPosition(int,Jewel);
	  Jewel deleteAtGivenPosition(int);
	  Jewel deleteAtFirst();
	  Jewel deleteAtLast();
	  int getSize();
	  int display();
	  Jewel retrieveElementAtGivenIndex(int);
	  int makeListEmpty();
	  Jewel searchElement(Jewel);

};
