#include"BST.h"
Jewel::Jewel()
{
	id=0;
	strcpy(design,"null");
	gst=0.0;
	costPerGram=0;
}
Jewel::Jewel(int i,float g,char des[],int cost)
{ 
	id=i;
	strcpy(design,des);
	gst=g;
	costPerGram=cost;
}
Jewel::Jewel(const Jewel& j)
{
	id=j.id;
	strcpy(design,j.design);
	gst=j.gst;
	costPerGram=j.costPerGram;
}
Jewel::Jewel(int cost)
{
	id=cost;
	strcpy(design,"null");
	gst=0.0;
	costPerGram=0;
}
bool Jewel::operator<(Jewel j)
{
	return id<j.id;
}
bool Jewel::operator>(Jewel j)
{
    return id>j.id;
}
bool Jewel::operator==(Jewel j)
{
	if(id==j.id)
	    return true;
	return false;
}
bool Jewel::operator!=(Jewel j)
{
	if(*this==j)
	   return false;
    return true;	   
}
Jewel Jewel::operator=(Jewel j)
{
	gst=j.gst;
	strcpy(design,j.design);
	id=j.id;
	costPerGram=j.costPerGram;
	return *this;
}
Jewel Jewel::operator=(int x)
{
	gst=float(x);
	strcpy(design,"saravana");
	id=x;
	costPerGram=x;
	return *this;
}
istream& operator>>(istream& myin,Jewel &j)
{
	cout<<"\nEnter Jewel Id: ";
	cin>>j.id;
	cout<<"\nEnter Jewel Gst: ";
	cin>>j.gst;
	cout<<"\nEnter Jewel Design: ";
	cin>>j.design;
	cout<<"\nEnter Cost Of One Gram: ";
	cin>>j.costPerGram;
	return myin;
}
ostream& operator<<(ostream& myout,Jewel &j)
{
    cout<<"\nJewel Id: "<<j.id<<"\tJewel Design: "<<j.design<<"\tJewel Gst: "<<j.gst<<"\tJewelCostPerGram: "<<j.costPerGram;
	cout<<"\n";
    return myout;
}
Node::Node()
{
	data=0;
	left=NULL;
	right=NULL;
}
Node::Node(Jewel dat,Node *lef,Node *righ)
{
	data=dat;
	left=lef;
	right=righ;
}
Node::Node(const Node& n)
{
	data=n.data;
	left=n.left;
	right=n.right;
}
Node::~Node()
{
	delete left;
	delete right;
}
BST::BST()
{
	root=NULL;
}
BST::BST(const BST &b)
{
	root=b.root;
}
BST::BST(Node *roo)
{
	root =roo;
}
BST::~BST()
{
	delete root;
}
Node* BST::getRoot()
{
	return root;
}
Node* BST::insert(Node *newnode)
{
	if(root==NULL)
	{
		root=newnode;
	}
	else
	{
		Node *temp=root;
		Node *parent;
		while(temp!=NULL)
		{
			if(temp->data<newnode->data)
			{
			   parent=temp;
			   temp=temp->right;
			}
			else if(temp->data>newnode->data)
			{
			   parent=temp;
			   temp=temp->left;
			}
			else if(temp->data==newnode->data)
			   return NULL;
		}
		if(parent->data<newnode->data)
		   parent->right=newnode;
		else if(parent->data>newnode->data)
		   parent->left=newnode;
		else if(parent->data==newnode->data)
			return NULL;
	}
	return root;
}
bool BST::isEmpty()
{
	return root==NULL;
}
void BST::inorder(Node *temp)
{
	if(temp!=NULL)
	{
		inorder(temp->left);
		cout<<temp->data;
		inorder(temp->right);
	}
}
void BST::preorder(Node *temp)
{
	if(temp!=NULL)
	{
		cout<<temp->data;
		preorder(temp->left);
		preorder(temp->right);
	}
}
void BST::postorder(Node* temp)
{
	if(temp!=NULL)
	{
		postorder(temp->left);
		postorder(temp->right);
		cout<<temp->data;
	}
}
int BST::getSize(Node* temp,int cnt)
{
	if(temp!=NULL)
	{
		cnt++;
		getSize(temp->left,cnt);
		getSize(temp->right,cnt);
	}
	else
	   return cnt;
}
Jewel BST::search(Jewel j)
{
	Node *temp=root;
	while(temp!=NULL)
	{
		if(temp->data<j)
		   temp=temp->right;
		else if(temp->data>j)
		   temp=temp->left;
	    else if(temp->data==j)
		   return temp->data;
	}
	Jewel test;
	return test;
}
Jewel BST::findMax()
{
  if(!isEmpty())
  {
	Node *temp=root;
	//Node *parent;
	while(temp->right!=NULL)
	{
		//parent=temp;
		temp=temp->right;
	}
	return temp->data;
  }
  Jewel test;
  return test;
}
Jewel BST::findMin()
{
	if(!isEmpty())
	{
		Node *temp=root;
		Node *parent;
		while(temp!=NULL)
		{
			parent=temp;
			temp=temp->left;
		}
		return parent->data;
	}
	Jewel test;
	return test;
}
void BST::setRoot()
{
	root=NULL;
}
Jewel BST::deleteNode(Jewel j)
{
	Jewel test;
	if((root->data==j)&&(root->right==NULL&&root->left==NULL))
	{
	   Jewel ret=root->data;	
       root=NULL;
       //root=NULL;	   
	   return ret;	   
	}
	else
	{	
	   Node *temp=root;
	   Node *parent=NULL;
	
		while(temp!=NULL)
		{   
		    if(temp->data==j)
			{
			    Jewel ret=temp->data;
			    if(temp->left==NULL&&temp->right==NULL)
				{
					if(parent->left==temp)
					   parent->left=NULL;
					else
					   parent->right=NULL;					   
				}
				else if(temp->left==NULL&&temp->right!=NULL)
				{
				  if(temp==root)
				  {
					  root=temp->right;
				  }
				  else
				  {
					if(parent->left==temp)
					   parent->left=temp->right;
					else
					   parent->right=temp->right;
				  }
				}
				else if(temp->left!=NULL&&temp->right==NULL)
				{
				  if(temp==root)
				  { 
				      root=temp->left;
				  }
				  else
				  {
					if(parent->left==temp)
					   parent->left=temp->left;
					else
					   parent->right=temp->left;
				  }
				}
				else if(temp->right!=NULL&&temp->left!=NULL)
				{
					Node *temp1=temp->right;
					Node *parent1=temp;
					while(temp1->left!=NULL)
					{
						  parent1=temp1;
					      temp1=temp1->left;
					}
			        temp->data=temp1->data;
					if(temp1->right==NULL&&temp1->left==NULL)
					{
						if(parent1->right==temp1)
						   parent1->right=NULL;
						else
						   parent1->left=NULL;
					}
					else
					{
						parent1->right=temp1->right;
					}
				}
				return ret;
			}
			else if(temp->data>j)
			{
				parent=temp;
			    temp=temp->left;	
			}
			else
			{
				parent=temp;
				temp=temp->right;
			}
		}
	}
	return test;
}
