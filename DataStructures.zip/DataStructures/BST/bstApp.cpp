#include"BST.h"
int main()
{
	cout<<"\n......Binary Search Tree......\n";
    int choice;
	BST b;
	do
	{
		cout<<"\n     Menu:\n";
		cout<<"\n1.Check Whether The Store Is Empty\n";
		cout<<"\n2.Add A Jewel\n";
		cout<<"\n3.Display The Jewels By Inorder Traversal\n";
		cout<<"\n4.Display The Jewels By Preorder Traversal\n";
		cout<<"\n5.Display The Jewel By Postorder Traversal\n";
		cout<<"\n6.Get The Total Number Of Jewels\n";
		cout<<"\n7.Search The Jewel By CostPerGram\n";
		cout<<"\n8.Find The Jewel With Minimum Cost\n";
		cout<<"\n9.Find The Jewel With Maximum Cost\n";
		cout<<"\n10.Delete A Jewel\n";
		cout<<"\n11.Exit\n";
		cout<<"\nEnter Your Choice: ";
		cin>>choice;
		if(choice==1)
		{
			if(b.isEmpty())
			   cout<<"\nYes The Store Is Empty!\n";
			else
			   cout<<"\nNo The Store Is Not Empty!\n";
		}
		else if(choice==2)
		{
			cout<<"\nEnter The Jewel Details To Add: \n";
			Jewel j;
			cin>>j;
			Node *newnode = new Node(j,NULL,NULL);
			if(b.insert(newnode)==NULL)
			   cout<<"\nThe Jewel Cost Must Be Unique! Duplications Are Not Allowed..Failed To Add.\n";
			else
			   cout<<"\nSuccessfully Added!\n";
		}
		else if(choice==3)
		{
		  if(!b.isEmpty())
		  {
			cout<<"\nDisplay BY Inorder Traversal: \n";
			b.inorder(b.getRoot());
		  }
		  else 
		    cout<<"\nStore Is Empty! Nothing To Display.\n";
		}
		else if(choice==4)
		{
		  if(!b.isEmpty())
		  {
			cout<<"\nDisplay By Preorder: \n";
			b.preorder(b.getRoot());
		  }
		  else
		    cout<<"\nStore Is Empty! Nothing To Display.\n";
		}
		else if(choice==5)
		{
		   if(!b.isEmpty())
		   {
			cout<<"\nDisplay By Postorder:\n";
			b.postorder(b.getRoot());
		   }
		   else
		     cout<<"\nStore Is Empty! Nothing To Display.\n";
		}
		else if(choice==6)
		{
		    int count=0;
			cout<<"\nSize: "<<b.getSize(b.getRoot(),count)<<"\n";
		}
		else if(choice==7)
		{
			int cost;
			cout<<"\nEnter The Jewel CostPerGram to Search: ";
			cin>>cost;
			Jewel j(cost);
			Jewel test;
		  if(!b.isEmpty())
		  {
			if(b.search(j)==test)
			    cout<<"\nThere Is No Jewel Available With This CostPerGram!\n";
			else
			{
			    cout<<"\nThe Jewel You Are Looking For Is: \n";
				Jewel J=b.search(j);
				cout<<J;
		    }
		  }
         else
             cout<<"\nStore Being Empty!\n";		 
	
		}
		else if(choice==8)
		{
			Jewel test;
			if(b.findMin()==test)
			   cout<<"\nOOPS! Store Is Empty!\n";
			else
			{
				cout<<"\nThe Jewel You Are Looking For Is: \n";
				Jewel j=b.findMin();
				cout<<j;
			}
		}
		else if(choice==9)
		{
			Jewel test;
			if(b.findMax()==test)
			  cout<<"\nOOPS! Store Is Empty\n";
			else
			{
				cout<<"\nThe Jewel You Are Looking For Is:\n";
				Jewel j=b.findMax();
				cout<<j;
			}
		}
		else if(choice==11)
		{
			break;
		}
		else if(choice==10)
		{
		  if(!b.isEmpty())
		  {
			int cost;
			cout<<"\nEnter The Cost Of The Jewel To Delete: ";
			cin>>cost;
			Jewel J(cost);
			Jewel test;
			Jewel out;
			out=b.deleteNode(J);
			if(out==test)
			{
				cout<<"\nThere Is No Jewel Available With This Cost..Deletion Unsuccessful!\n";
			}
			else 
			{
				cout<<"\n\tDeleted Jewel: \n"; 
				
                cout<<out;		
			}
		}
		else
		{
			cout<<"\nStore Is Empty! Removal Not Possible..\n";
		}
		}
		else 
		{
			cout<<"\nInvalid Key! Press The Valid Key.\n";
		}
	}while(choice!=11);
}
