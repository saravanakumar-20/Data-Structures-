#include<string.h>
#include<iostream>
using namespace std;
class Jewel
{
 private:
         int id;
		 float gst;
		 char design[20];
		 int costPerGram;
  public:
         Jewel();
         Jewel(int,float,char[],int);
		 Jewel(const Jewel&);
		 Jewel(int);
         bool operator==(Jewel);
         Jewel operator=(Jewel);
		 Jewel operator=(int);
		 bool operator>(Jewel);
		 bool operator<(Jewel);
		 bool operator!=(Jewel);
  friend istream& operator>>(istream&,Jewel&);
  friend ostream& operator<<(ostream&,Jewel&);		
  friend class Node;  
};
class Node 
{
 private:
	    Jewel data;
	    Node *left; //self referencing pointer variable to hold the address of left child.
	    Node *right; //self referencing pointer variable to hold the address of right child.
 public:
        Node();
		Node(Jewel,Node*,Node*);
		Node(const Node&);
		~Node();
 friend class BST;
};
class BST
{
 private:
	    Node *root;//root pointer variable to hold the very first node in the tree.
 public:
        BST();
		BST(Node*);
		BST(const BST&);
		~BST();
		Node* getRoot();
		bool isEmpty();
		Node* insert(Node*);
		void inorder(Node*);
		void postorder(Node*);
		void preorder(Node*);
		int getSize(Node*,int);
		void setRoot();
		Jewel search(Jewel);
		Jewel findMin();
		Jewel findMax();
		Jewel deleteNode(Jewel);
};
