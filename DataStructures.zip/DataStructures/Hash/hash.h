#include<iostream>
using namespace std;
#include<string.h>
class Jewel
{
	private:
	  int id;
	  int cost_per_gram;
	  char design[20];
	  float gst;
	public:
	  Jewel();
	  Jewel operator=(int);
	  void get_data();
	  void display_data();
	  Jewel operator=(Jewel);
	  bool operator==(Jewel);
	  int get_id();
};
class HashTable
{
	private:
	   int capacity;
	   int size;
	   Jewel *array;
	public:
	   HashTable(int);
	   int hash(int);
	   int insert(Jewel);
	   int remove(int);
	   int search(int);
	   Jewel find_element(int);
	   void display();
};