#include"hash.h"
Jewel::Jewel()
{
	id=0;
	strcpy(design,"null");
	cost_per_gram=0;
	gst=0.0;
}
Jewel Jewel::operator=(Jewel j)
{
	 id=j.id;
	 cost_per_gram=j.cost_per_gram;
	 gst=j.gst;
	 strcpy(design,j.design);
	 return *this;
}
bool Jewel::operator==(Jewel j)
{
	return j.id==id;
}
Jewel Jewel::operator=(int x)
{
	id=x;
	cost_per_gram=x;
	gst=0.0;
	strcpy(design,"null");
	return *this;
}
void Jewel::get_data()
{
	cout<<"\nEnter Jewel_id:";
	cin>>id;
	cout<<"\nEnter Jewel_design: ";
	cin>>design;
	cout<<"\nEnter Jewel_gst: ";
	cin>>gst;
	cout<<"\nEnter cost_per_gram: ";
	cin>>cost_per_gram;
}
void Jewel::display_data()
{
	cout<<"\nJewel_id: "<<id;
	cout<<"\nJewel_design: "<<design;
	cout<<"\nJewel_gst: "<<gst;
	cout<<"\ncost_per_gram: "<<cost_per_gram;
	cout<<"\n";
}
int Jewel::get_id()
{
	return id;
}
HashTable::HashTable(int c)
{
	capacity=c;
	size=0;
	array=new Jewel[capacity];
}
int HashTable::hash(int id)
{
	return id%capacity;
}
int HashTable::insert(Jewel j)
{
	if(size==capacity)
	   return 0;
	int value=hash(j.get_id());
	while(array[value].get_id()!=0 && array[value].get_id()!=j.get_id())
	{
		value=hash(value+1);
	}
	if(array[value]==j)
	   return -1;
	array[value]=j;
	size++;
	return 1;
}
int HashTable::remove(int idi)
{
	if(size==0)
	   return 0;
	int value=hash(idi);
	int cnt=0;
	while(cnt<=value)
	{
		if(array[value].get_id()!=idi)
		{
			value=hash(value+1);
			cnt++;
			continue;
		}
		else
		{
			array[value]=0;
			return 1;
		}
	}
	return -1;
}
int HashTable::search(int idi)
{
	if(size==0)
	   return 0;
	int value=hash(idi);
	int cnt=1;
	while(cnt<=value)
	{
	  if(array[value].get_id()!=idi)
	  {
		  value=hash(value+1);
		  continue;
	  }
	  else
	    return 1;
		cnt++;
	}
	return -1;
}
Jewel HashTable::find_element(int idi)
{
	Jewel empty;
    if(size==0)
       return empty;
    int value=hash(idi);
    int cnt=1;
    while(cnt<=value)
	{
		if(array[value].get_id()!=idi)
	    {
			value=hash(value+1);
			continue;
		}
        else
          return array[value];
        cnt++;	  
	}		
	return empty;
}
void HashTable::display()
{
	if(size==0)
	   cout<<"\nNo jewel is there in the shop";
	else
	{
		int i;
		for(i=0;i<capacity;i++)
		{
		   array[i].display_data();
		}
	}
}