#include"hash.h"
int main()
{
  int choice;
  cout<<"\nEnter the capacity of your store: ";
  int cap;
  cin>>cap;
  HashTable h(cap);
  do
  {
	  cout<<"\nmenu: ";
	  cout<<"\n1.add a jewel";
	  cout<<"\n2.remove a jewel";
	  cout<<"\n3.display all the jewels";
	  cout<<"\n4.search a jewel with id";
	  cout<<"\n5.find a jewel";
	  cout<<"\n6.exit";
	  cout<<"\nEnter your choice: ";
	  cin>>choice;
	  if(choice==1)
	  {
		  Jewel j;
		  j.get_data();
		  int cas=h.insert(j);
		  if(cas==0)
		     cout<<"\ntable full";
		  else
		     cout<<"\nsuccesfully added";
	  }
	  if(choice==2)
	  {
		  cout<<"\nenter the id to remove";
		  int id;
		  cin>>id;
		  int cas=h.remove(id);
		  if(cas==1)
		    cout<<"\nsuccessfully removed";
	      else
		    cout<<"\ntable empty";
	  }
	  if(choice==3)
	  {
		  h.display();
	  }
	  if(choice==4)
	  {
		  int id;
		  cout<<"\nenter the id to search;";
		  cin>>id;
		  int cas=h.search(id);
		  if(cas==1)
		     cout<<"\nyes present";
		  else if(cas==0)
		     cout<<"\nempty";
		  else
		     cout<<"\nnot present";
	  }
	  if(choice==5)
	  {
		  Jewel j;
		  cout<<"\nenter the id to find: ";
		  int id;
		  cin>>id;
		  j=h.find_element(id);
		  Jewel empty;
		  if(!(empty==j))
		     j.display_data();
		  else
		     cout<<"\nelement not present";
	  }
  }while(choice!=6); 
}